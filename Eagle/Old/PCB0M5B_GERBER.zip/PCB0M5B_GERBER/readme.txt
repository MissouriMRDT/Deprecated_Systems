File listing:
*.top  = top layer - gerber 274x
*.bot  = bottom layer - gerber 274x
*.smt  = solder mask top - gerber 274x
*.smb  = solder mask bottom - gerber 274x
*.sst  = silk screen top - gerber 274x
*.gdr  = drill drawing / dimension - gerber 274x
*.drd  = excellon drill file
*.dri  = drill tool listing
*.dim  = board outline - gerber 274x


Contact info:
Frank Marshall
SDELC
Missouri S&T
1051 N. Bishop Avenue
116 Kummer Student Design Center 
Rolla, MO 65409
fem3n3@mst.edu

Lukas M�ller
lkm8c3@mail.mst.edu